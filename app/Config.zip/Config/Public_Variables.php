<?php

class Public_Variables
{
    public $BASE_URL = '/web/chip/';
    public $ASSETS_URL = '/web/chip/assets_main/';
    public $db_pass = '';
}
